import * as React from 'react';
import { Link, NavLink } from 'react-router-dom';
var menuTop = require('../images/menuIcon.png');
var menuBottom = require('../images/menuIconHover.png');



export class NavMenu extends React.Component<{}, {}> {

    openSideNav() {
    console.log('The link was clicked.');
    }

    public render() {
        return <div className='main-nav'>
            <div className='navbar navbar-inverse'>
                <div onClick={this.openSideNav} className="menu-icon"> 
                    <img className='menu-bottom' src={String(menuBottom)} />
                    <img className='menu-top' src={String(menuTop)} />
                </div>
                <div className='navbar-header'>
                            
                    
                            <Link className='navbar-brand' to={ '/' }>WorkoutTracker</Link>
                        </div>
                        </div>
                </div>;
    }





}
