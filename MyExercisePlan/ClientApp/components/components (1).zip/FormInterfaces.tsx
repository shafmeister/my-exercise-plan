﻿
export interface phoneDetails {
    name: string,
    manufacturer: string,
    cpuCores: number,
    screenSize: number,
    price: number,
    ramSize: number
};

