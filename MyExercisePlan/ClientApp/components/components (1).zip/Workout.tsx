﻿import * as React from 'react';
import * as Constants from './Constants';

export class Workout extends React.Component<{}, { workout: WorkoutState }> {
    constructor() {
        super();
        this.state = { workout: Constants.workout };
    }

    render() {
        return (
            <div>
                <div>
                    Workout: {this.state.workout.name}
                </div>
                <div>
                    <Exercises exercises={this.state.workout.exercises} />
                </div>
            </div>
        )
    }
}

class Exercises extends React.Component<{ exercises: WorkoutExercise[] }, {}> {
    render() {
        const exercises = this.props.exercises;
        const exerciseList = exercises.map((exercise) =>
            <div key={exercise.id}>{exercise.name}
                <Sets sets={exercise.sets} />
            </div>
        );

        return (
            <div>
                {exerciseList}
            </div>
        )
    }
};

class Sets extends React.Component<{ sets: ExerciseSet[]}, {}> {
    render() {
        const sets = this.props.sets;
        const setsList = sets.map((set) =>
            <div key={set.id} >
                <label className={set.id.toString() + "-rep-label"}>Sets:</label>
                <input className={set.id.toString() + "-rep"} defaultValue={set.reps.toString()} />
                <label className={set.weight.toString() + "-weight-label"}>Weight:</label>
                <input defaultValue={set.weight.toString()} /> 
            </div>
        )

        return (
            <div>{setsList}</div>
        )

    }
}

interface WorkoutState {
    id: number,
    name: string,
    exercises: WorkoutExercise[]
};

interface WorkoutExercise {
    id: number,
    name: string,
    sets: ExerciseSet[]
    
};

interface ExerciseSet {
    id: number,
    weight: number,
    reps: number
};

export default Workout;