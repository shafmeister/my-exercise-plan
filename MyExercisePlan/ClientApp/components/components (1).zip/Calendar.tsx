import * as React from 'react';
import './Calendar.css';
import * as Constants from './Constants'

export class Calendar extends React.Component<{}, {}> {
    constructor() {
        super();
        this.state = {
            weeks: GetWeeks()
        };
}
    render() {
        return (
            <div className="calendar-container">
                <div className="calendar-header">
                    {CalendarHeader()}
                </div> 
                <div className="calendar-body">
                    <table>
                       <CalendarBody />
                    </table>
                </div>    
			</div>
        );
    }
}

function CalendarHeader() {
    var currentDate = new Date();
    var monthYear = Constants.months[currentDate.getMonth()] + " " + currentDate.getFullYear();
    return monthYear;
} 





function CalendarBody() {
    const weeks = Constants.calDays;
    const days = Constants.daysOfWeekShort;
    const listDays = days.map((day) =>
        <th>{day}</th>
    );
    const buildBody = weeks.map((week) =>
        <tr>{CalendarWeek(week)}</tr>
    );

    return (
        <tbody>
            {listDays}
            {buildBody}
        </tbody>
    );

}


function CalendarWeek(week: (number | null)[]) {
    const days = week;
    const buildWeeks = days.map((day) =>
        <td>{day}</td>
    );

    return [
        buildWeeks
    ];
}

function GetWeeks() {
    //Date information
    var currentDate = new Date();
    var currentMonth = currentDate.getMonth();
    var currentYear = currentDate.getFullYear();
    var lastDay = new Date(currentYear, currentMonth + 1, 0);
    var firstDay = new Date(currentYear, currentMonth, 1);
    //Loop increments
    var calDay = 1;
    var calPosition = 1;
    var dayOffSet = firstDay.getDay();
    var calendar = "<tr>";
    console.log(dayOffSet);
    var weekArray = [];
    var currentWeek = [0];
    weekArray.push(currentWeek);
    //Build array

    return weekArray;
    //Build calendar
    /*
    while (calDay <= lastDay.getDate()) {
        var loopDay = new Date(currentYear, currentMonth, calDay);
        if (calDay + dayOffSet == calPosition) {
            calendar = calendar + "<td>" + calDay + "</td>";
            calDay++;
        }
        else {
            calendar = calendar + "<td></td>";
        }
        if (calPosition % 7 == 0 && calPosition != 0) {
            calendar = calendar + "</tr><tr>";
        }
        calPosition++;
    }
*/

    /*return (
        <tr>{calendar}</tr>
    );
    */
}

export default Calendar;